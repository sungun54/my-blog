package com.sbs.kys.at.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbs.kys.at.dao.ArticleDao;
import com.sbs.kys.at.dto.Article;
import com.sbs.kys.at.dto.ArticleReply;
import com.sbs.kys.at.util.Util;

@Service
public class ArticleService {
	@Autowired
	private ArticleDao articleDao;
	
	public List<Article> getForPrintArticles(int page) {
		
		int itemsInAPage = 5;
		int limitFrom = (page - 1) * itemsInAPage;
		
		List<Article> articles = articleDao.getForPrintArticles(itemsInAPage, limitFrom);
		
		return articles;
	}

	public Article getArticleById(int id) {
		Article article = articleDao.getArticleById(id);
		return article;
	}

	public Article Modify(int id, String body, String title) {
		Article article = articleDao.Modify(id, body, title);
		return article;
	}

	public long doWrite(Map<String, Object> param) {
		articleDao.doWrite(param);

		return Util.getAsLong(param.get("id"));
	}

	public void modify(Map<String, Object> param) {
		articleDao.modify(param);
	}

	public void delete(long id) {
		articleDao.delete(id);
	}

	public void hitUp(int id) {
		articleDao.hitUp(id);
	}

	public int getTotalCount() {
		return articleDao.getTotalCount();
	}

	public Article getArticleByNextId(int id) {
		return articleDao.getArticleByNextId(id);
	}

	public Article getArticleByPrevId(int id) {
		return articleDao.getArticleByPrevId(id);
	}

	public List<Article> getForSearchPrintArticles(int page, String searchKeyword, String searchKeywordType) {
		int itemsInAPage = 5;
		int limitFrom = (page - 1) * itemsInAPage;
		
		List<Article> articles = articleDao.getForSearchPrintArticles(itemsInAPage, limitFrom, searchKeyword, searchKeywordType);
		
		return articles;
	}

	public int getTotalSearchCount(String searchKeyword, String searchKeywordType) {
		return articleDao.getTotalSearchCount(searchKeyword, searchKeywordType);
	}

	public List<ArticleReply> getArticleReplies(int id) {
		List<ArticleReply> getArticleReplies = articleDao.getArticleReplies(id);
		return getArticleReplies;
	}

	public void doReplyWrite(Map<String, Object> param) {
		articleDao.doReplyWrite(param);
	}

}
