package com.sbs.kys.at.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sbs.kys.at.dto.Article;
import com.sbs.kys.at.dto.ArticleReply;

@Mapper
public interface ArticleDao {
	public List<Article> getForPrintArticles(int itemsInAPage, int limitFrom);

	public Article getArticleById(int id);

	public Article Modify(int id, String body, String title);

	public void doWrite(Map<String, Object> param);

	public void modify(Map<String, Object> param);

	public void delete(long id);

	public void hitUp(int id);

	public int getTotalCount();

	public Article getArticleByNextId(int id);
	
	public Article getArticleByPrevId(int id);

	public List<Article> getForSearchPrintArticles(int itemsInAPage, int limitFrom, String searchKeyword,
			String searchKeywordType);

	public int getTotalSearchCount(String searchKeyword, String searchKeywordType);

	public List<ArticleReply> getArticleReplies(int id);

	public void doReplyWrite(Map<String, Object> param);
}
