package com.sbs.java.blog.dao;

import java.sql.Connection;
import java.util.Map;

import com.sbs.java.blog.dto.Member;
import com.sbs.java.blog.util.DBUtil;

public class MemberDao {
	
	private Connection dbConn;

	public MemberDao(Connection dbConn) {
		this.dbConn = dbConn;
	}
	
	public int join(String loginId, String name, String nickname, String loginPw) {
		String sql = "";

		sql += String.format("INSERT INTO Member ");
		sql += String.format("SET regDate = NOW()");
		sql += String.format(", loginId = '%s'", loginId);
		sql += String.format(", loginPw = '%s'", loginPw);
		sql += String.format(", nickname = '%s'", nickname);
		sql += String.format(", name = '%s'", name);
		
		return DBUtil.insert(dbConn, sql);
	}

	public Map<String, Object> login(String loginId, String loginPw) {
		String sql = "";
		
		sql += String.format("SELECT * ");
		sql += String.format("FROM `Member` ");
		sql += String.format("WHERE loginId = '%s' ", loginId);
		sql += String.format("AND loginPw = '%s'", loginPw);
		
		return DBUtil.selectRow(dbConn, sql);
	}

	public Map<String, Object> loginIdOverlap(String loginId) {
		String sql = "";
		
		sql += String.format("SELECT * ");
		sql += String.format("FROM `Member` ");
		sql += String.format("WHERE loginId = '%s' ", loginId);
		
		return DBUtil.selectRow(dbConn, sql);
	}
}
