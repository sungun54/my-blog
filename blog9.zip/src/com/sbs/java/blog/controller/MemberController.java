package com.sbs.java.blog.controller;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.service.ArticleService;

public class MemberController extends Controller {
	
	public MemberController(Connection dbConn,	String actionMethodName, HttpServletRequest req, HttpServletResponse resp) {
		super(dbConn, actionMethodName, req, resp);
	}
	
	@Override
	public String doAction() {
		return "";
	}

}