package com.sbs.java.blog.sv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;
import com.sbs.java.blog.util.DBUtil;

@WebServlet("/s/article/showDetail")
public class ArticleShowDetail extends HttpServlet {
	private String getCategoryName(int cateItemId) {
		String url = "jdbc:mysql://site21.iu.gy:3306/site21?serverTimezone=Asia/Seoul&useOldAliasMetadataBehavior=true";
		String user = "site21";
		String password = "sbs123414";
		String driverName = "com.mysql.cj.jdbc.Driver";

		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM cateItem ");
		sql += String.format("WHERE id = %d ", cateItemId);
		Connection connection = null;

		Category cateItem = null;

		try {
			Class.forName(driverName);
			connection = DriverManager.getConnection(url, user, password);
			Map<String, Object> row = DBUtil.selectRow(connection, sql);
			cateItem = new Category(row);
		} catch (SQLException e) {
			System.err.printf("[SQL 예외] : %s\n", e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.printf("[드라이버 클래스 로딩 예외] : %s\n", e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
		}

		return cateItem.getName();
	}
	private List<Article> getAllArticles(int cateItemId){
		String url = "jdbc:mysql://site21.iu.gy:3306/site21?serverTimezone=Asia/Seoul&useOldAliasMetadataBehavior=true";
		String user = "site21";
		String password = "sbs123414";
		String driverName = "com.mysql.cj.jdbc.Driver";
		
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE cateItemId = %d ", cateItemId);
		
		Connection connection = null;
		
		List<Article> articles = new ArrayList<>();
		
		try {
			Class.forName(driverName);
			connection = DriverManager.getConnection(url, user, password);
			
			List<Map<String, Object>> rows = DBUtil.selectRows(connection, sql);
			for( Map<String, Object> row : rows) {
				articles.add(new Article(row));
			}
			
		} catch (SQLException e) {
			System.err.printf("[SQL 예외] : %s\n", e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.printf("[드라이버 클래스 로딩 예외] : %s\n", e.getMessage());
		}
		finally {
			if(connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
		}
		return articles;
	}
	private List<Article> getArticles(int cateItemId, int page) {
		String url = "jdbc:mysql://site21.iu.gy:3306/site21?serverTimezone=Asia/Seoul&useOldAliasMetadataBehavior=true";
		String user = "site21";
		String password = "sbs123414";
		String driverName = "com.mysql.cj.jdbc.Driver";

		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE cateItemId = %d ", cateItemId);
		sql += String.format("ORDER BY id DESC LIMIT %d, 5", (page - 1) * 5);
		Connection connection = null;

		List<Article> articles = new ArrayList<>();

		try {
			Class.forName(driverName);
			connection = DriverManager.getConnection(url, user, password);

			List<Map<String, Object>> rows = DBUtil.selectRows(connection, sql);
			for (Map<String, Object> row : rows) {
				articles.add(new Article(row));
			}

		} catch (SQLException e) {
			System.err.printf("[SQL 예외] : %s\n", e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.printf("[드라이버 클래스 로딩 예외] : %s\n", e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
		}
		return articles;
	}
	private List<Category> getCateItems(){
		String url = "jdbc:mysql://site21.iu.gy:3306/site21?serverTimezone=Asia/Seoul&useOldAliasMetadataBehavior=true";
		String user = "site21";
		String password = "sbs123414";
		String driverName = "com.mysql.cj.jdbc.Driver";
		
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM cateItem ");
		sql += String.format("ORDER BY id ASC ");		
		
		Connection connection = null;
		
		List<Category> cateItems = new ArrayList<>();
		
		try {
			Class.forName(driverName);
			connection = DriverManager.getConnection(url, user, password);
			
			List<Map<String, Object>> rows = DBUtil.selectRows(connection, sql);
			for( Map<String, Object> row : rows) {
				cateItems.add(new Category(row));
			}
			
		} catch (SQLException e) {
			System.err.printf("[SQL 예외] : %s\n", e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.printf("[드라이버 클래스 로딩 예외] : %s\n", e.getMessage());
		}
		finally {
			if(connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
		}
		return cateItems;
	}	
	private Article getArticle(int id){
		String url = "jdbc:mysql://site21.iu.gy:3306/site21?serverTimezone=Asia/Seoul&useOldAliasMetadataBehavior=true";
		String user = "site21";
		String password = "sbs123414";
		String driverName = "com.mysql.cj.jdbc.Driver";
		
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE id = %d", id);
		
		Connection connection = null;		
		
		Article article = null;
		
		try {
			Class.forName(driverName);
			connection = DriverManager.getConnection(url, user, password);
			
			Map<String, Object> row = DBUtil.selectRow(connection, sql);
			
			article = new Article(row);
			
		} catch (SQLException e) {
			System.err.printf("[SQL 예외] : %s\n", e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.printf("[드라이버 클래스 로딩 예외] : %s\n", e.getMessage());
		}
		finally {
			if(connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
		}
		return article;
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		
		int id = Integer.parseInt(request.getParameter("id"));
		int cateItemId = Integer.parseInt(request.getParameter("cateItemId"));
		int page = 1;
		
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}	

		List<Article> articles = getArticles(cateItemId, page);
		request.setAttribute("articles", articles);
		List<Article> allArticles = getAllArticles(cateItemId);		
		request.setAttribute("allArticles", allArticles);	
		String cateName = getCategoryName(cateItemId);
		request.setAttribute("cateName", cateName);		
		Article article = getArticle(id);		
		request.setAttribute("article", article);
		List<Category> categories = getCateItems();		
		request.setAttribute("categories", categories);
		request.setAttribute("page", page);
		request.getRequestDispatcher("/jsp/article/detail.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(	request, response);
	}

}

