package com.sbs.java.blog.service;

import java.sql.Connection;
import java.util.Map;

import com.sbs.java.blog.dao.MemberDao;
import com.sbs.java.blog.dto.Member;

public class MemberService extends Service {
	
	private MemberDao memberDao;
	
	public MemberService(Connection dbConn) {
		memberDao = new MemberDao(dbConn);
	}
	
	public int join(String loginId, String name, String nickname, String loginPw, String email) {
		return memberDao.join(loginId, name, nickname, loginPw, email);
	}

	public Map<String, Object> login(String loginId, String loginPw) {
		return memberDao.login(loginId, loginPw);
	}

	public Map<String, Object> loginIdOverlap(String loginId) {
		return memberDao.loginIdOverlap(loginId);
	}
	
}
