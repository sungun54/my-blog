package com.sbs.java.blog.sv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Category;
import com.sbs.java.blog.util.DBUtil;

@WebServlet("/s/home/aboutMe")
public class HomeAboutMeServlet extends HttpServlet {
	private List<Category> getCateItems(){
		String url = "jdbc:mysql://localhost:3306/site21?serverTimezone=Asia/Seoul&useOldAliasMetadataBehavior=true";
		String user = "site21";
		String password = "sbs123414";
		String driverName = "com.mysql.cj.jdbc.Driver";
		
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM cateItem ");
		sql += String.format("ORDER BY id ASC ");		
		
		Connection connection = null;
		
		List<Category> cateItems = new ArrayList<>();
		
		try {
			Class.forName(driverName);
			connection = DriverManager.getConnection(url, user, password);
			
			List<Map<String, Object>> rows = DBUtil.selectRows(connection, sql);
			for( Map<String, Object> row : rows) {
				cateItems.add(new Category(row));
			}
			
		} catch (SQLException e) {
			System.err.printf("[SQL 예외] : %s\n", e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.printf("[드라이버 클래스 로딩 예외] : %s\n", e.getMessage());
		}
		finally {
			if(connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
		}
		return cateItems;
	}	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		List<Category> categories = getCateItems();		
		request.setAttribute("categories", categories);		
		request.getRequestDispatcher("/jsp/home/aboutMe.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
