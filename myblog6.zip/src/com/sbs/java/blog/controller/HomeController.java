package com.sbs.java.blog.controller;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;
import com.sbs.java.blog.service.ArticleService;

public class HomeController extends Controller {
	private ArticleService articleService;

	public HomeController(Connection dbConn) {
		articleService = new ArticleService(dbConn);
	}

	public String doAction(String actionMethodName, HttpServletRequest req, HttpServletResponse resp) {
		switch (actionMethodName) {
		case "main":
			return doActionMain(req, resp);
		case "board":
			return doActionBoard(req, resp);
		case "aboutMe":
			return doActionAboutMe(req, resp);
		}

		return "";
	}

	private String doActionBoard(HttpServletRequest req, HttpServletResponse resp) {
		int page = 1;

		if (req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}

		List<Article> articles = articleService.getArticles(page);
		List<Article> allArticles = articleService.getAllArticles();
		req.setAttribute("allArticles", allArticles);
		req.setAttribute("articles", articles);
		List<Category> categories = articleService.getCateItems();
		req.setAttribute("categories", categories);
		req.setAttribute("page", page);

		return "home/board";
	}

	private String doActionAboutMe(HttpServletRequest req, HttpServletResponse resp) {
		int cateItemId = 0;
		if (req.getParameter("cateItemId") != null) {
			cateItemId = Integer.parseInt(req.getParameter("cateItemId"));
		}

		List<Category> categories = articleService.getCateItems();
		req.setAttribute("categories", categories);

		return "home/aboutMe";
	}

	private String doActionMain(HttpServletRequest req, HttpServletResponse resp) {
		int page = 1;

		if (req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}

		String searchKeyword = "space";
		if (req.getParameter("searchKeyword") != null) {
			searchKeyword = req.getParameter("searchKeyword");
		}

		List<Article> articles = null;
		List<Article> allArticles = null;

		if (searchKeyword.equals("space")) {
			articles = articleService.getArticles(page);
			allArticles = articleService.getAllArticles();
		} else {
			articles = articleService.getArticles(page, searchKeyword);
			allArticles = articleService.getAllArticles(searchKeyword);
		}
		req.setAttribute("allArticles", allArticles);
		req.setAttribute("articles", articles);
		List<Category> categories = articleService.getCateItems();
		req.setAttribute("categories", categories);
		req.setAttribute("page", page);
		return "home/main";
	}
}