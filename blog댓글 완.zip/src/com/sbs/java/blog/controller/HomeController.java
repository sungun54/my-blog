package com.sbs.java.blog.controller;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Article;

public class HomeController extends Controller {

	public HomeController(Connection dbConn, String actionMethodName, HttpServletRequest req, HttpServletResponse resp) {
		super(dbConn, actionMethodName, req, resp);
	}
	
	public void beforeAction() {
		super.beforeAction();
	}
	
	@Override
	public String doAction() {
		switch (actionMethodName) {
		case "main":
			return doActionMain(req, resp);
		case "board":
			return doActionBoard(req, resp);
		case "aboutMe":
			return doActionAboutMe(req, resp);
		}

		return "";
	}

	private String doActionBoard(HttpServletRequest req, HttpServletResponse resp) {
		int page = 1;

		if (req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}
		
		int id = 0;
		if(req.getParameter("id") != null) {                                                                                                                                                                                                                                                                                   
			 
			id = Integer.parseInt(req.getParameter("id"));
		}		
		int itemsInAPage = 5;
		
		if(id != 0) {
			Article article = articleService.getArticle(id);		
			req.setAttribute("article", article);
			page = articleService.getPageWhereArticleInclude(itemsInAPage, id);
		}
		
		List<Article> articles = articleService.getArticles(page);
		List<Article> allArticles = articleService.getAllArticles();
		req.setAttribute("allArticles", allArticles);
		req.setAttribute("articles", articles);
		req.setAttribute("page", page);

		return "home/board.jsp";
	}

	private String doActionAboutMe(HttpServletRequest req, HttpServletResponse resp) {
		return "home/aboutMe.jsp";
	}

	private String doActionMain(HttpServletRequest req, HttpServletResponse resp) {
		int page = 1;

		if (req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}

		String searchKeyword = "";
		if (req.getParameter("searchKeyword") != null) {
			searchKeyword = req.getParameter("searchKeyword");
		}
		int id = 0;
		if(req.getParameter("id") != null) {
			id = Integer.parseInt(req.getParameter("id"));
		}		
		int itemsInAPage = 5;
		
		if(id != 0) {
			Article article = articleService.getArticle(id);		
			req.setAttribute("article", article);
			page = articleService.getPageWhereArticleInclude(itemsInAPage, id);
		}
		List<Article> articles = null;
		List<Article> allArticles = null;

		if (searchKeyword.equals("")) {
			articles = articleService.getArticles(page);
			allArticles = articleService.getAllArticles();
		} else {
			articles = articleService.getArticles(page, searchKeyword);
			allArticles = articleService.getAllArticles(searchKeyword);
		}
		req.setAttribute("searchKeyword", searchKeyword);
		req.setAttribute("allArticles", allArticles);
		req.setAttribute("articles", articles);
		req.setAttribute("page", page);
		return "home/main.jsp";
	}
}