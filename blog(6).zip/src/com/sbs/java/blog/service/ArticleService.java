package com.sbs.java.blog.service;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dao.ArticleDao;
import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;

public class ArticleService extends Service{

	private ArticleDao articleDao;

	public ArticleService(Connection dbConn, HttpServletRequest req, HttpServletResponse resp) {
		super(req, resp);
		articleDao = new ArticleDao(dbConn, req, resp);
	}

	public List<Article> getForPrintListArticles(int page, int cateItemId) {
		return articleDao.getForPrintListArticles(page, cateItemId);
	}

	public void writeArticles(String title, String body) {
		articleDao.writeArticles(title, body);
	}

	public List<Article> getAllArticles(int cateItemId) {
		return articleDao.getAllArticles(cateItemId);
	}

	public String getCategoryName(int cateItemId) {
		return articleDao.getCategoryName(cateItemId);
	}

	public Article getArticle(int id) {
		return articleDao.getArticle(id);
	}

	public List<Category> getCateItems() {
		return articleDao.getCateItems();
	}

	public List<Article> getAllArticles() {
		return articleDao.getAllArticles();
	}

	public List<Article> getArticles(int page, String searchKeyword) {
		return articleDao.getArticles(page, searchKeyword);
	}

	public List<Article> getArticles(int page) {
		return articleDao.getArticles(page);
	}

	public List<Article> getAllArticles(String searchKeyword) {
		return articleDao.getAllArticles(searchKeyword);
	}

}