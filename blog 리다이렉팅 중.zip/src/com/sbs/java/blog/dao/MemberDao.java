package com.sbs.java.blog.dao;

import java.sql.Connection;
import java.util.Map;

import com.sbs.java.blog.dto.ArticleReply;
import com.sbs.java.blog.dto.Member;
import com.sbs.java.blog.util.DBUtil;
import com.sbs.java.blog.util.SecSql;

public class MemberDao {
	
	private Connection dbConn;

	public MemberDao(Connection dbConn) {
		this.dbConn = dbConn;
	}
	
	public int join(String loginId, String name, String nickname, String loginPw, String email) {
		SecSql secSql = new SecSql();
		/*
		sql += String.format("INSERT INTO Member ");
		sql += String.format("SET regDate = NOW()");
		sql += String.format(", loginId = '%s'", loginId);
		sql += String.format(", loginPw = '%s'", loginPw);
		sql += String.format(", nickname = '%s'", nickname);
		sql += String.format(", name = '%s'", name);
		*/
		secSql.append("INSERT INTO `Member` ");
		secSql.append("SET regDate = NOW()");
		secSql.append(", updateDate = NOW()");
		secSql.append(", loginId = ? ", loginId);
		secSql.append(", loginPw = ? ", loginPw);
		secSql.append(", nickname = ? ", nickname);
		secSql.append(", name = ? ", name);
		secSql.append(", email = ? ", email);	
		
		
		return DBUtil.insert(dbConn, secSql);
	}

	public Map<String, Object> login(String loginId, String loginPw) {
		SecSql secSql = new SecSql();
		
		secSql.append("SELECT * ");
		secSql.append("FROM `Member` ");
		secSql.append("WHERE loginId = ? ", loginId);
		secSql.append("AND loginPw = ?", loginPw);
		
		return DBUtil.selectRow(dbConn, secSql);
		/*
		String sql = "";
		
		sql += String.format("SELECT * ");
		sql += String.format("FROM `Member` ");
		sql += String.format("WHERE loginId = '%s' ", loginId);
		sql += String.format("AND loginPw = '%s'", loginPw);
		
		return DBUtil.selectRow(dbConn, sql);
		*/
	}

	public boolean isJoinableLoginId(String loginId) {
		SecSql sql = SecSql.from("SELECT COUNT(*) AS cnt");
		sql.append("FROM `Member`");
		sql.append("WHERE loginId = ?", loginId);

		return DBUtil.selectRowIntValue(dbConn, sql) == 0;
	}

	public boolean isJoinableNickname(String nickname) {
		SecSql sql = SecSql.from("SELECT COUNT(*) AS cnt");
		sql.append("FROM `Member`");
		sql.append("WHERE nickname = ?", nickname);

		return DBUtil.selectRowIntValue(dbConn, sql) == 0;
	}

	public boolean isJoinableEmail(String email) {
		SecSql sql = SecSql.from("SELECT COUNT(*) AS cnt");
		sql.append("FROM `Member`");
		sql.append("WHERE email = ?", email);

		return DBUtil.selectRowIntValue(dbConn, sql) == 0;
	}
	
	public Member getMemberById(int id) {
		SecSql sql = SecSql.from("SELECT *");
		sql.append("FROM `Member`");
		sql.append("WHERE id = ?", id);

		return new Member(DBUtil.selectRow(dbConn, sql));
	}
}
