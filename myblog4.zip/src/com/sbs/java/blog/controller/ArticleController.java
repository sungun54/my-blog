package com.sbs.java.blog.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;
import com.sbs.java.blog.service.ArticleService;

public class ArticleController extends Controller {
	private ArticleService articleService;

	public ArticleController(Connection dbConn) {
		articleService = new ArticleService(dbConn);
	}

	public String doAction(String actionMethodName, HttpServletRequest req, HttpServletResponse resp) {
		switch (actionMethodName) {
		case "list":
			return doActionList(req, resp);
		case "doWrite":
			return doActionWrite(req, resp);
		case "detail":
			return doActionDetail(req, resp);
		}

		return "";
	}

	

	private String doActionDetail(HttpServletRequest req, HttpServletResponse resp) {
		
		int id = 1;
		if(req.getParameter("id") != null) {
			id = Integer.parseInt(req.getParameter("id"));
		}
		int cateItemId = 0;
		if(req.getParameter("cateItemId")!=null){
			cateItemId = Integer.parseInt(req.getParameter("cateItemId"));
		}
		int page = 1;
		if(req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}	
		
		List<Article> articles =articleService.getForPrintListArticles(page, cateItemId);
		req.setAttribute("articles", articles);
		List<Article> allArticles = articleService.getAllArticles(cateItemId);		
		req.setAttribute("allArticles", allArticles);	
		String cateName = articleService.getCategoryName(cateItemId);
		req.setAttribute("cateName", cateName);		
		Article article = articleService.getArticle(id);		
		req.setAttribute("article", article);
		List<Category> categories = articleService.getCateItems();		
		req.setAttribute("categories", categories);
		req.setAttribute("page", page);

		return "article/detail";
	}

	private String doActionWrite(HttpServletRequest req, HttpServletResponse resp) {
		String title = null;		
		if (req.getParameter("title") != null) {
			title = req.getParameter("title");
		}

		String body = null;
		if (req.getParameter("body") != null) {
			body = req.getParameter("body");
		}

		articleService.writeArticles(title, body);
		
		return "article/doWrite";
	}

	private String doActionList(HttpServletRequest req, HttpServletResponse resp) {
		int cateItemId = 0;
		if (req.getParameter("cateItemId") != null) {
			cateItemId = Integer.parseInt(req.getParameter("cateItemId"));
		}
		int page = 1;		
		if(req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}	
		List<Article> allArticles = articleService.getAllArticles(cateItemId);		
		req.setAttribute("allArticles", allArticles);	
		List<Article> articles = articleService.getForPrintListArticles(page, cateItemId);
		req.setAttribute("articles", articles);
		List<Category> categories = articleService.getCateItems();
		req.setAttribute("categories", categories);
		String cateName = articleService.getCategoryName(cateItemId);
		req.setAttribute("cateName", cateName);
		req.setAttribute("page", page);
		req.setAttribute("cateItemId", cateItemId);
		return "article/list";
	}
}