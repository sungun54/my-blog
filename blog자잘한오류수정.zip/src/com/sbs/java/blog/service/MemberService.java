package com.sbs.java.blog.service;

import java.sql.Connection;
import java.util.Map;

import com.sbs.java.blog.dao.MemberDao;
import com.sbs.java.blog.dto.Attr;
import com.sbs.java.blog.dto.Member;

public class MemberService extends Service {
	
	private MemberDao memberDao;
	
	public MemberService(Connection dbConn) {
		memberDao = new MemberDao(dbConn);
	}
	
	public int join(String loginId, String name, String nickname, String loginPw, String email) {
		return memberDao.join(loginId, name, nickname, loginPw, email);
	}

	public Map<String, Object> login(String loginId, String loginPw) {
		return memberDao.login(loginId, loginPw);
	}


	public Member getMemberById(int loginedMemberId) {
		return memberDao.getMemberById(loginedMemberId);
	}

	public boolean isJoinableLoginId(String loginId) {
		return memberDao.isJoinableLoginId(loginId);
	}
	
	public boolean isJoinableNickname(String nickname) {
		return memberDao.isJoinableNickname(nickname);
	}

	public boolean isJoinableEmail(String email) {
		return memberDao.isJoinableEmail(email);
	}

	public Map<String, Object> findLoginId(String name, String email) {
		return memberDao.findLoginId(name, email);
	}

	public void temporaryPw(int id, String uuid) {
		memberDao.temporaryPw(id, uuid);
	}

	public Map<String, Object> findLoginPw(String name, String email, String loginId) {
		return memberDao.findLoginPw(name, email, loginId);
	}

	public void Modify(String nickname, String email, int id) {
		memberDao.Modify(nickname, email, id);		
	}

	public boolean nicknameCheck(String nickname) {
		return memberDao.nicknameCheck(nickname);	
	}

	public void pwModify(int id, String loginPw) {
		memberDao.pwModify(id, loginPw);	
		
	}

	public boolean pwConfirm(int id, String loginPw) {
		return memberDao.pwConfirm(id, loginPw);		
	}

	public void mailAuth(String loginId) {
		memberDao.mailAuth(loginId);
	}

	public boolean keyConfirm(String loginId, String key) {
		return memberDao.keyConfirm(loginId, key);
	}
	

	public Attr get(String name) {
		return memberDao.get(name);
	}

	public int setValue(String name, String value) {
		return memberDao.setValue(name, value);
	}

	public String getValue(String name) {
		return memberDao.getValue(name);
	}

	public int remove(String name) {
		return memberDao.remove(name);
	}

	public void deleteMember(String loginId) {
		memberDao.deleteMember(loginId);
	}

	public Member getMemberByLoginId(String loginId) {
		return memberDao.getMemberByLoginId(loginId);
	}

	public boolean getRegDateMember(String loginId) {
		return memberDao.getRegDateMember(loginId);
	}
	
}
