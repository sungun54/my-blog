package com.sbs.java.blog.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;
import com.sbs.java.blog.util.DBUtil;

public class ArticleDao extends Dao {
	private Connection dbConn;
	private Statement stmt;
	private DBUtil dbutil;

	public ArticleDao(Connection dbConn, HttpServletRequest req, HttpServletResponse resp) {
		super(req, resp);
		this.dbConn = dbConn;
		this.dbutil = new DBUtil(req, resp);
	}

	public List<Article> getForPrintListArticles(int page, int cateItemId) {
		String sql = "";

		int itemsInAPage = 5;
		int limitFrom = (page - 1) * itemsInAPage;

		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		// sql += String.format("WHERE displayStatus = 1 ");
		if (cateItemId != 0) {
			sql += String.format("WHERE cateItemId = %d ", cateItemId);
		}
		sql += String.format("ORDER BY id DESC ");
		sql += String.format("LIMIT %d, %d ", limitFrom, itemsInAPage);

		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		List<Article> articles = new ArrayList<>();

		for (Map<String, Object> row : rows) {
			articles.add(new Article(row));
		}

		return articles;
	}

	public void writeArticles(String title, String body) {

		String sql = "";
		sql += String.format("INSERT INTO Article ");
		sql += String.format("SET regDate = now()");
		sql += String.format(", updateDate = now()");
		sql += String.format(", title = %s", title);
		sql += String.format(", `body` = %s", body);

		try {
			stmt = dbConn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			int affectedRows = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (dbConn != null) {
				try {
					dbConn.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, 커넥션 닫기] : %s\n", e.getMessage());
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					System.err.printf("[SQL 예외, stmt 닫기] : %s\n", e.getMessage());
				}
			}
		}

	}

	public List<Article> getAllArticles(int cateItemId) {
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE cateItemId = %d ", cateItemId);

		List<Article> articles = new ArrayList<>();

		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		for (Map<String, Object> row : rows) {
			articles.add(new Article(row));
		}

		return articles;
	}

	public String getCategoryName(int cateItemId) {

		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM cateItem ");
		sql += String.format("WHERE id = %d ", cateItemId);

		Category cateItem = null;

		Map<String, Object> row = dbutil.selectRow(dbConn, sql);
		cateItem = new Category(row);

		return cateItem.getName();
	}

	public Article getArticle(int id) {
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE id = %d", id);

		Article article = null;

		Map<String, Object> row = dbutil.selectRow(dbConn, sql);

		article = new Article(row);

		return article;
	}

	public List<Category> getCateItems() {

		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM cateItem ");
		sql += String.format("ORDER BY id ASC ");

		List<Category> cateItems = new ArrayList<>();

		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		for (Map<String, Object> row : rows) {
			cateItems.add(new Category(row));
		}

		return cateItems;
	}

	public List<Article> getAllArticles() {
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");

		List<Article> articles = new ArrayList<>();

		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		for (Map<String, Object> row : rows) {
			articles.add(new Article(row));
		}

		return articles;
	}

	public List<Article> getArticles(int page, String searchKeyword) {
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += "WHERE title LIKE '%" + searchKeyword + "%' ";
		sql += String.format("ORDER BY id DESC LIMIT %d, 5", (page - 1) * 5);
		List<Article> articles = new ArrayList<>();
		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		for (Map<String, Object> row : rows) {
			articles.add(new Article(row));
		}

		return articles;
	}

	public List<Article> getArticles(int page) {
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += String.format("ORDER BY id DESC LIMIT %d, 5", (page - 1) * 5);

		List<Article> articles = new ArrayList<>();
		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		for (Map<String, Object> row : rows) {
			articles.add(new Article(row));
		}

		return articles;
	}

	public List<Article> getAllArticles(String searchKeyword) {
		String sql = "";
		sql += String.format("SELECT * ");
		sql += String.format("FROM Article ");
		sql += "WHERE title LIKE '%" + searchKeyword + "%' ";

		List<Article> articles = new ArrayList<>();

		List<Map<String, Object>> rows = dbutil.selectRows(dbConn, sql);
		for (Map<String, Object> row : rows) {
			articles.add(new Article(row));
		}

		return articles;
	}

	public int getHowManyId(int id, int cateItemId) {
		String sql = "";
		sql += String.format("SELECT COUNT(*) AS cnt ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE displayStatus = 1 ");
		if (cateItemId != 0) {
			sql += String.format("AND cateItemId = %d ", cateItemId);
		}
		sql += String.format("AND id > %d", id);

		int howManyId = 0;

		howManyId = dbutil.selectRowIntValue(dbConn, sql);

		return howManyId;
	}

	public int getOverCountOnList(int cateItemId, int id) {
		String sql = "";
		sql += String.format("SELECT COUNT(*) AS cnt ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE displayStatus = 1 ");
		if (cateItemId != 0) {
			sql += String.format("AND cateItemId = %d ", cateItemId);
		}
		sql += String.format("AND id > %d ", id);

		return dbutil.selectRowIntValue(dbConn, sql);
	}

	public int getOverCountOnList(int id) {
		String sql = "";
		sql += String.format("SELECT COUNT(*) AS cnt ");
		sql += String.format("FROM Article ");
		sql += String.format("WHERE displayStatus = 1 ");
		sql += String.format("AND id > %d ", id);

		return dbutil.selectRowIntValue(dbConn, sql);
	}
}