package com.sbs.java.blog.service;

public abstract class Service {

}
