package com.sbs.java.blog.exception;

public class SQLErrorException extends RuntimeException {
	public SQLErrorException(String message) {
		super(message);
	}
}	
