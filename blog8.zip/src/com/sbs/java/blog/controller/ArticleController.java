package com.sbs.java.blog.controller;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;
import com.sbs.java.blog.util.Util;

public class ArticleController extends Controller {
	public ArticleController(Connection dbConn,	String actionMethodName, HttpServletRequest req, HttpServletResponse resp) {
		super(dbConn, actionMethodName, req, resp);
	}

	public void beforeAction() {
		super.beforeAction();
	}
	
	public String doAction() {
		
		switch (actionMethodName) {
		case "list":
			return doActionList(req, resp);
		case "doWrite":
			return doActionWrite(req, resp);
		case "detail":
			return doActionDetail(req, resp);
		}

		return "";
	}

	

	private String doActionDetail(HttpServletRequest req, HttpServletResponse resp) {
		if (Util.empty(req, "id")) {
			return "html:id를 입력해주세요.";
		}

		if (Util.isNum(req, "id") == false) {
			return "html:id를 정수로 입력해주세요.";
		}
		
		int id = 1;
		if(req.getParameter("id") != null) {
			id = Integer.parseInt(req.getParameter("id"));
		}
		int cateItemId = 0;
		if(req.getParameter("cateItemId")!=null){
			cateItemId = Integer.parseInt(req.getParameter("cateItemId"));
		}
		int page = 1;
		if(req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}	
		
		List<Article> articles = articleService.getForPrintListArticles(page, cateItemId);
		req.setAttribute("articles", articles);
		List<Article> allArticles = articleService.getAllArticles(cateItemId);		
		req.setAttribute("allArticles", allArticles);	
		String cateName = articleService.getCategoryName(cateItemId);
		req.setAttribute("cateName", cateName);		
		Article article = articleService.getArticle(id);		
		req.setAttribute("article", article);
		req.setAttribute("page", page);

		return "article/detail.jsp";
	}

	private String doActionWrite(HttpServletRequest req, HttpServletResponse resp) {
		String title = null;		
		if (req.getParameter("title") != null) {
			title = req.getParameter("title");
		}

		String body = null;
		if (req.getParameter("body") != null) {
			body = req.getParameter("body");
		}

		articleService.writeArticles(title, body);
		
		return "article/doWrite.jsp";
	}

	private String doActionList(HttpServletRequest req, HttpServletResponse resp) {
		int id = 0;
		if(req.getParameter("id") != null) {
			id = Integer.parseInt(req.getParameter("id"));
		}		

		int cateItemId = 0;
		if (req.getParameter("cateItemId") != null) {
			cateItemId = Integer.parseInt(req.getParameter("cateItemId"));
		}
		int page = 1;		
		
		if(req.getParameter("page") != null) {
			page = Integer.parseInt(req.getParameter("page"));
		}
		
		int itemsInAPage = 5;
		
		if(id != 0) {
			Article article = articleService.getArticle(id);		
			req.setAttribute("article", article);
			page = articleService.getPageWhereArticleInclude(itemsInAPage, cateItemId, id);
		}
			
		List<Article> allArticles = articleService.getAllArticles(cateItemId);		
		req.setAttribute("allArticles", allArticles);			
		List<Article> articles = articleService.getForPrintListArticles(page, cateItemId);
		req.setAttribute("articles", articles);
		String cateName = articleService.getCategoryName(cateItemId);
		req.setAttribute("cateName", cateName);
		req.setAttribute("page", page);
		req.setAttribute("cateItemId", cateItemId);
		return "article/list.jsp";
	}
}