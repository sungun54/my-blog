package com.sbs.java.blog.controller;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.service.MailService;
import com.sbs.java.blog.util.Util;

public class MemberController extends Controller {
	private String gmailId;
	private String gmailPw;
	
	public MemberController(Connection dbConn, String actionMethodName, HttpServletRequest req,
			HttpServletResponse resp, String gmailId, String gmailPw) {
		super(dbConn, actionMethodName, req, resp);
		this.gmailId = gmailId;
		this.gmailPw = gmailPw;
	}

	@Override
	public String getControllerName() {
		return "member";
	}

	public void beforeAction() {
		super.beforeAction();
	}

	@Override
	public String doAction() {
		switch (actionMethodName) {
		case "login":
			return doActionLogin();
		case "doLogin":
			return doActionDoLogin();
		case "doLogout":
			return doActionDoLogout();
		case "join":
			return doActionJoin();
		case "doJoin":
			return doActionDoJoin();
		case "findLoginId":
			return doActionFindLoginId();
		case "doFindLoginId":
			return doActionDoFindLoginId();
		case "findLoginPw":
			return doActionFindLoginPw();
		case "doFindLoginPw":
			return doActionDoFindLoginPw();
		case "myPage":
			return doActionMyPage();
		case "memberModify":
			return doActionMemberModify();
		case "doMemberModify":
			return doActionDoMemberModify();
		case "pwConfirm":
			return doActionMemberPwModifyConfirm();
		case "doPwConfirm":
			return doActionDoMemberPwModifyConfirm();
		case "pwModify":
			return doActionMemberPwModify();
		case "doPwModify":
			return doActionDoMemberPwModify();
		case "doMailAuth":
			return doActionDoMailAuth();
		}

		return "";
	}
	
	
	
	private String doActionDoMailAuth() {
		String loginId = req.getParameter("loginId");
		String key = req.getParameter("key");
		
		boolean check = memberService.keyConfirm(loginId, key);
		
		if(check == false) {
			return "html:<script> alert('인증이 실패했습니다.');location.replace('../home/main'); </script>";
		}
		
		memberService.mailAuth(loginId);
		
		return "html:<script> alert('인증이 완료됐습니다.');location.replace('../member/login'); </script>";
	}

	private String doActionDoMemberPwModifyConfirm() {
		int id = Integer.parseInt(req.getParameter("id"));
		String loginPw = req.getParameter("loginPw");
				
		boolean check = memberService.pwConfirm(id, loginPw);
		
		if(check == false) {
			return "html:<script> alert('비밀번호가 일치하지않습니다.'); history.back(); </script>";
		}
			
		return "html:<script>location.replace('pwModify'); </script>";
	}

	private String doActionMemberPwModifyConfirm() {
		return "member/pwConfirm.jsp";
	}

	private String doActionDoMemberPwModify() {
		int id = Integer.parseInt(req.getParameter("id"));
		String loginPw = req.getParameter("loginPwReal");
		
		memberService.pwModify(id, loginPw);
		
		return "html:<script> alert('비밀번호가 변경되었습니다.'); location.replace('../home/main'); </script>";
	}

	private String doActionMemberPwModify() {
		return "member/pwModify.jsp";
	}

	private String doActionMemberModify() {
		return "member/modify.jsp";
	}

	private String doActionDoMemberModify() {
		int id = Integer.parseInt(req.getParameter("id"));
		String nickname = req.getParameter("nickname");
		String email = req.getParameter("email");
		
		boolean check = memberService.nicknameCheck(nickname);
		
		if(check == false) {
			return "html:<script> alert('이미 사용 중인 닉네임입니다.'); history.back();</script>";
		}
		
		memberService.Modify(nickname, email, id);
		
		return "html:<script> alert('수정되었습니다.'); location.replace('../home/main'); </script>";
	}

	private String doActionMyPage() {
		return "member/modify.jsp";
	}

	private String doActionDoFindLoginPw() {
		String loginId = req.getParameter("loginId");
		String name = req.getParameter("name");
		String email = req.getParameter("email");

		Map<String, Object> member = memberService.findLoginPw(name, email, loginId);

		if (member.size() == 0) {
			return "html:<script> alert('일치하는 계정이 없습니다.'); history.back();</script>";
		}
		
		String uuid = ""
				+ "";
		
		for (int i = 0; i < 5; i++) {
		  uuid = UUID.randomUUID().toString().replaceAll("-", ""); // -를 제거해 주었다.
		  uuid = uuid.substring(0, 10); //uuid를 앞에서부터 10자리 잘라줌.
		}
		
		int id = (int)member.get("id");
		String uuidReal = uuid;
		try {
			uuid = Util.sha256(uuid);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		memberService.temporaryPw(id, uuid);
		MailService mailService = new MailService(gmailId, gmailPw, gmailId, "관리자", dbConn);
		mailService.send(email, "임시비빌번호입니다.", uuidReal);	
		
		return "html:<script> alert('메일로 임시비밀번호를 발송하였습니다.'); window.close(); </script>";
	}

	private String doActionFindLoginPw() {
		return "member/findLoginPw.jsp";
	}

	private String doActionDoFindLoginId() {
		String name = req.getParameter("name");
		String email = req.getParameter("email");

		Map<String, Object> member = memberService.findLoginId(name, email);

		if (member.size() == 0) {
			return "html:<script> alert('일치하는 아이디가 없습니다.'); window.close();</script>";
		}

		return "html:<script> alert('아이디는 " + member.get("loginId") + "'); window.close();</script>";
	}

	private String doActionFindLoginId() {
		return "member/findLoginId.jsp";
	}

	private String doActionDoLogout() {
		String redirectUrl = req.getParameter("redirectUrl");
//		String cateItemId = "";
//		if(req.getParameter("cateItemId") != null) {
//			cateItemId = req.getParameter("cateItemId");
//		}
//		String page = "";
//		if(req.getParameter("page") != null) {
//			page = req.getParameter("page");
//		}
//		
//		if(!cateItemId.equals("") && page.equals("")) {
//			redirectUrl+= "&cateItemId=" + cateItemId; 
//		}		
//		if(!page.equals("") && cateItemId.equals("")) {
//			redirectUrl+= "&page=" + page;
//		}
//		if(!cateItemId.equals("") && !page.equals("")) {
//			redirectUrl+= "&cateItemId=" + cateItemId + "&page=" + page; 
//		}	

		session.removeAttribute("loginedMemberId");

		return "html:<script> alert('로그아웃되었습니다.'); location.replace('../home/main'); </script>";
	}

	private String doActionDoJoin() {
		String loginId = req.getParameter("loginId");
		String name = req.getParameter("name");
		String nickname = req.getParameter("nickname");
		String loginPw = req.getParameter("loginPwReal");
		String email = req.getParameter("email");

		boolean isJoinableLoginId = memberService.isJoinableLoginId(loginId);

		if (isJoinableLoginId == false) {
			return String.format("html:<script> alert('%s(은)는 이미 사용중인 아이디 입니다.'); history.back(); </script>", loginId);
		}

		boolean isJoinableNickname = memberService.isJoinableNickname(nickname);

		if (isJoinableNickname == false) {
			return String.format("html:<script> alert('%s(은)는 이미 사용중인 닉네임 입니다.'); history.back(); </script>", nickname);
		}

		boolean isJoinableEmail = memberService.isJoinableEmail(email);

		if (isJoinableEmail == false) {
			return String.format("html:<script> alert('%s(은)는 이미 사용중인 이메일 입니다.'); history.back(); </script>", email);
		}

		int id = memberService.join(loginId, name, nickname, loginPw, email);
		
		MailService mailService = new MailService(gmailId, gmailPw, gmailId, "관리자", dbConn);		
				
		mailService.mailSendWithUserKey(email, loginId, req);		
	
		//mailService.send(email, "회원가입을 축하드립니다.", "반갑습니다.");			
		
		//return "html:<script> alert('" + id + "번 회원이 생성되었습니다.'); location.replace('../home/main'); </script>";
		
		return "html:<script> alert('이메일 인증이 발송되었습니다..'); location.replace('../home/main'); </script>";
	}

	private String doActionJoin() {
		return "member/join.jsp";
	}

	private String doActionDoLogin() {
		String loginId = req.getParameter("loginId");
		String loginPw = req.getParameter("loginPw");
		String redirectUrl = req.getParameter("redirectUrl");
//		String cateItemId = "";
//		if(req.getParameter("cateItemId") != null) {
//			cateItemId = req.getParameter("cateItemId");
//		}
//		String page = "";
//		if(req.getParameter("page") != null) {
//			page = req.getParameter("page");
//		}
//		
//		if(!cateItemId.equals("") && page.equals("")) {
//			redirectUrl+= "&cateItemId=" + cateItemId; 
//		}		
//		if(!page.equals("") && cateItemId.equals("")) {
//			redirectUrl+= "&page=" + page;
//		}
//		if(!cateItemId.equals("") && !page.equals("")) {
//			redirectUrl+= "&cateItemId=" + cateItemId + "&page=" + page; 
//		}
		Map<String, Object> member = memberService.login(loginId, loginPw);
		
		if (member.size() == 0) {
			return "html:<script> alert('아이디 혹은 비밀번호가 일치하지않습니다.'); history.back(); </script>";
		}

		if((int)member.get("mailAuthStatus") == 0) {
			return "html:<script> alert('이메일인증을 먼저 해주세요.'); history.back(); </script>";
		}
		
		session.setAttribute("loginedMemberId", member.get("id"));

		if (redirectUrl == "") {
			return "html:<script> alert('" + member.get("id")
					+ "번 회원이 로그인되었습니다.'); location.replace('../home/main'); </script>";
		}

		return "html:<script> alert('" + member.get("id") + "번 회원이 로그인되었습니다.'); location.replace('" + redirectUrl
				+ "'); </script>";
	}

	private String doActionLogin() {
		return "member/login.jsp";
	}

}
