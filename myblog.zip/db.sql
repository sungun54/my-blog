DROP DATABASE IF EXISTS blog;
CREATE DATABASE blog;
USE blog;

CREATE TABLE Article(
  id INT(10) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
  regDate DATETIME NOT NULL,
  updateDate DATETIME NOT NULL,
  title CHAR(200) NOT NULL,
  `body` LONGTEXT NOT NULL
);

SELECT * 
FROM Article;

INSERT INTO Article
SET regDate = NOW(),
updateDate = NOW(),
title ="제목2",
`body` ="내용2";

SELECT * FROM Article ORDER BY id DESC 