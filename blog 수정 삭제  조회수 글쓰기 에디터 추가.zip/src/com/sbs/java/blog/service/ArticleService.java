package com.sbs.java.blog.service;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dao.ArticleDao;
import com.sbs.java.blog.dto.Article;
import com.sbs.java.blog.dto.Category;

public class ArticleService extends Service{

	private ArticleDao articleDao;

	public ArticleService(Connection dbConn) {
		articleDao = new ArticleDao(dbConn);
	}

	public List<Article> getForPrintListArticles(int page, int cateItemId) {
		return articleDao.getForPrintListArticles(page, cateItemId);
	}

	public List<Article> getAllArticles(int cateItemId) {
		return articleDao.getAllArticles(cateItemId);
	}

	public String getCategoryName(int cateItemId) {
		return articleDao.getCategoryName(cateItemId);
	}

	public Article getArticle(int id) {
		return articleDao.getArticle(id);
	}

	public List<Category> getCateItems() {
		return articleDao.getCateItems();
	}

	public List<Article> getAllArticles() {
		return articleDao.getAllArticles();
	}

	public List<Article> getArticles(int page, String searchKeyword) {
		return articleDao.getArticles(page, searchKeyword);
	}

	public List<Article> getArticles(int page) {
		return articleDao.getArticles(page);
	}

	public List<Article> getAllArticles(String searchKeyword) {
		return articleDao.getAllArticles(searchKeyword);
	}


	public int getPageWhereArticleInclude(int itemsInAPage, int cateItemId, int id) {
		int overCount = articleDao.getOverCountOnList(cateItemId, id);
		int rank = overCount + 1;
		
		return (int)Math.ceil(rank / (double)itemsInAPage);
	}

	public int getPageWhereArticleInclude(int itemsInAPage, int id) {
		int overCount = articleDao.getOverCountOnList(id);
		int rank = overCount + 1;
		
		return (int)Math.ceil(rank / (double)itemsInAPage);
	}

	public int write(int cateItemId, String title, String body) {
		return articleDao.write(cateItemId, title, body);
	}

	public void delete(int id) {
		articleDao.delete(id);
	}

	public void modify(int id, int cateItemId, String title, String body) {
		articleDao.modify(id, cateItemId, title, body);
	}

	public void increaseHit(int id) {
		articleDao.increaseHit(id);		
	}

}