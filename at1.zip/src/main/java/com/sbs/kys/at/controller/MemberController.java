package com.sbs.kys.at.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sbs.kys.at.dto.Member;
import com.sbs.kys.at.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	private MemberService memberService;
	
	@RequestMapping("/member/login")
	public String showLogin() {
		return "member/login";
	}
	
	@RequestMapping("/member/doLogin")
	@ResponseBody
	public String doLogin(@RequestParam Map<String, Object> param, HttpSession session) {	
		
		Member matchedMember = memberService.getMatchedOne((String) param.get("loginId"),
				(String) param.get("loginPw"));

		if (matchedMember == null) {
			StringBuilder sb = new StringBuilder();
			sb.append("alert('일치하는 회원이 존재하지 않습니다.');");
			sb.append("history.back();");
			sb.insert(0, "<script>");
			sb.append("</script>");
			return sb.toString();
		}	
		StringBuilder sb = new StringBuilder();

		sb.append("alert('로그인에 성공하였습니다.');");
		sb.append("location.replace('../home/main');");

		sb.insert(0, "<script>");
		sb.append("</script>");
		
		session.setAttribute("loginedMemberId", matchedMember.getId());
		
		return sb.toString();
	}
	
	@RequestMapping("/member/doLogout")
	@ResponseBody
	public String doLogout(@RequestParam Map<String, Object> param, HttpSession session) {	
		
		session.removeAttribute("loginedMemberId");
		
		StringBuilder sb = new StringBuilder();
		String msg = "로그아웃 되었습니다.";
		sb.append("alert('" + msg + "');");
		sb.append("location.replace('../home/main');");
		sb.insert(0, "<script>");
		sb.append("</script>");
		return sb.toString();
		
	}
	
	@RequestMapping("/member/join")
	public String showJoin() {
		return "member/join";
	}

	@RequestMapping("/member/doJoin")
	@ResponseBody
	public String doJoin(@RequestParam Map<String, Object> param) {
		
		Map<String, Object> isJoinableLoginId = memberService.isJoinableLoginId((String)param.get("loginId"));
		
		if (((String) isJoinableLoginId.get("resultCode")).startsWith("F-")) {
			StringBuilder sb = new StringBuilder();
			String msg = (String)isJoinableLoginId.get("msg");
			sb.append("alert('" + msg + "');");
			sb.append("history.back();");
			sb.insert(0, "<script>");
			sb.append("</script>");
			return sb.toString();
		}
		Map<String, Object> isJoinableNickname = memberService.isJoinableNickname((String)param.get("nickname"));
		
		if (((String) isJoinableNickname.get("resultCode")).startsWith("F-")) {
			StringBuilder sb = new StringBuilder();
			String msg = (String)isJoinableNickname.get("msg");
			sb.append("alert('" + msg + "');");
			sb.append("history.back();");
			sb.insert(0, "<script>");
			sb.append("</script>");
			return sb.toString();
		}
		Map<String, Object> isJoinableEmail = memberService.isJoinableEmail((String)param.get("email"));
		
		if (((String) isJoinableEmail.get("resultCode")).startsWith("F-")) {
			StringBuilder sb = new StringBuilder();
			String msg = (String)isJoinableEmail.get("msg");
			sb.append("alert('" + msg + "');");
			sb.append("history.back();");
			sb.insert(0, "<script>");
			sb.append("</script>");
			return sb.toString();
		}
		
		String nickname = memberService.join(param);		
		
		String msg = nickname + "님 가입을 환영합니다.";

		StringBuilder sb = new StringBuilder();

		sb.append("alert('" + msg + "');");
		sb.append("location.replace('../home/main');");

		sb.insert(0, "<script>");
		sb.append("</script>");

		return sb.toString();
	}
}	
