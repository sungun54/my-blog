package com.sbs.kys.at.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sbs.kys.at.dto.Member;

@Mapper
public interface MemberDao {

	public void join(Map<String, Object> param);

	public int isJoinableLoginId(String loginId);

	public int isJoinableNickname(String nickname);

	public int isJoinableEmail(String email);
	
	public int login(Map<String, Object> param);

	public Member getMatchedOne(String loginId, String loginPw);

	public Member getMemberById(int id);
}