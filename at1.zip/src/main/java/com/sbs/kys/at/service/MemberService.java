package com.sbs.kys.at.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbs.kys.at.dao.MemberDao;
import com.sbs.kys.at.dto.Member;

@Service
public class MemberService {
	@Autowired
	private MemberDao memberDao;

	public String join(Map<String, Object> param) {
		memberDao.join(param);

		return (String)param.get("nickname");
	}

	public Map<String, Object> isJoinableLoginId(String loginId) {
		int isJoinableLoginId = memberDao.isJoinableLoginId(loginId);
		
		String resultCode = "";
		String msg = "";
		
		if ( isJoinableLoginId == 0 ) {
			resultCode = "S-1";
			msg = "사용가능한 로그인 ID 입니다.";
		}
		else {
			resultCode = "F-1";
			msg = "이미 사용중인 로그인 ID 입니다.";
		}
		
		Map<String, Object> rs = new HashMap<String, Object>();
		rs.put("resultCode", resultCode);
		rs.put("msg", msg);
		
		return rs;
	}

	public Map<String, Object> isJoinableNickname(String nickname) {
		int isJoinableNickname = memberDao.isJoinableNickname(nickname);
		
		String resultCode = "";
		String msg = "";
		
		if ( isJoinableNickname == 0 ) {
			resultCode = "S-1";
			msg = "사용가능한 닉네임 입니다.";
		}
		else {
			resultCode = "F-1";
			msg = "이미 사용중인 닉네임 입니다.";
		}
		
		Map<String, Object> rs = new HashMap<String, Object>();
		rs.put("resultCode", resultCode);
		rs.put("msg", msg);
		
		return rs;
	}

	public Map<String, Object> isJoinableEmail(String email) {
		int isJoinableEmail = memberDao.isJoinableEmail(email);
		
		String resultCode = "";
		String msg = "";
		
		if ( isJoinableEmail == 0 ) {
			resultCode = "S-1";
			msg = "사용가능한 이메일 입니다.";
		}
		else {
			resultCode = "F-1";
			msg = "이미 사용중인 이메일 입니다.";
		}
		
		Map<String, Object> rs = new HashMap<String, Object>();
		rs.put("resultCode", resultCode);
		rs.put("msg", msg);
		
		return rs;
	}

	public Member getMatchedOne(String loginId, String loginPw) {
		return memberDao.getMatchedOne(loginId, loginPw);
	}	
	
	public Member getMemberById(int id) {
		return memberDao.getMemberById(id);
	}
}
