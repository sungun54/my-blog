package com.sbs.kys.at.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sbs.kys.at.dto.Article;
import com.sbs.kys.at.dto.ArticleReply;
import com.sbs.kys.at.service.ArticleService;

@Controller
public class ArticleController {
	
	@Autowired
	private ArticleService articleService;

	@RequestMapping("/article/list")
	public String showList(@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(defaultValue = "") String searchKeyword,
			@RequestParam(defaultValue = "title") String searchKeywordType, Model model) {
		List<Article> articles = null;
		String alertMsg = null;
		int totalArticle = 0;
		if (searchKeyword.equals("")) {
			articles = articleService.getForPrintArticles(page);
			totalArticle = articleService.getTotalCount();
		} else {
			articles = articleService.getForSearchPrintArticles(page, searchKeyword, searchKeywordType);
			totalArticle = articleService.getTotalSearchCount(searchKeyword, searchKeywordType);
			if (articles.size() == 0) {
				alertMsg = "검색결과가 없습니다.";
				model.addAttribute("alertMsg", alertMsg);
				return "common/data";
			}
		}
		int totalPage = (int) Math.ceil(totalArticle / (double) 5);

		model.addAttribute("totalArticle", totalArticle);
		model.addAttribute("articles", articles);
		model.addAttribute("page", page);
		model.addAttribute("totalPage", totalPage);

		return "article/list";
	}

	@RequestMapping("/article/detail")
	public String showArticle(int id, Model model, HttpSession session) {
		Article article = articleService.getArticleById(id);

		Article nextArticle = articleService.getArticleByNextId(id);
		Article prevArticle = articleService.getArticleByPrevId(id);
		
		//List<ArticleReply> articleReplies = articleService.getArticleReplies(id);		
		
		articleService.hitUp(id);
		
		session.setAttribute("articleId", article.getId());
		
		model.addAttribute("article", article);
		//model.addAttribute("articleReplies", articleReplies);
		model.addAttribute("nextArticle", nextArticle);
		model.addAttribute("prevArticle", prevArticle);
		
		return "article/detail";
	}
	
	@RequestMapping("article/doReplyWrite")
	public String doWriteReply(Model model, @RequestParam Map<String, Object> param, HttpServletRequest request) {

		int loginedMemberId = (int) request.getAttribute("loginedMemberId");
		param.put("memberId", loginedMemberId);
		Map<String, Object> rs = articleService.doReplyWrite(param);

		String msg = (String) rs.get("msg");
		String redirectUrl = (String) param.get("redirectUrl");

		model.addAttribute("alertMsg", msg);
		model.addAttribute("locationReplace", redirectUrl);

		return "common/redirect";
	}

	@RequestMapping("article/doWriteReplyAjax")
	@ResponseBody
	public Map<String, Object> doWriteReplyAjax(@RequestParam Map<String, Object> param, HttpServletRequest request) {
		
		int loginedMemberId = (int) request.getAttribute("loginedMemberId");

		param.put("memberId", loginedMemberId);
		Map<String, Object> rs = articleService.doReplyWrite(param);

		return rs;
	}
	
	@RequestMapping("article/getForPrintArticleRepliesRs")
	@ResponseBody
	public Map<String, Object> getForPrintArticleRepliesRs(int id, int from) {
		List<ArticleReply> articleReplies = articleService.getArticleReplies(id, from);

		Map<String, Object> rs = new HashMap<>();
		rs.put("resultCode", "S-1");
		rs.put("msg", String.format("총 %d개의 댓글이 있습니다.", articleReplies.size()));
		rs.put("articleReplies", articleReplies);

		return rs;
	}
	
	@RequestMapping("/article/replyModify")
	public String showReplyModify(Model model) {
		return "article/replyModify";
	}
	
	@RequestMapping("/article/doReplyModify")
	@ResponseBody
	public String doReplyModify(@RequestParam Map<String, Object> param, int articleId) {
		articleService.doReplyModify(param);
				
		//String msg ="댓글이 수정되었습니다.";

		StringBuilder sb = new StringBuilder();

		//sb.append("alert('" + msg + "');");
		sb.append("location.replace('./detail?id=" + articleId + "');");

		sb.insert(0, "<script>");
		sb.append("</script>");

		return sb.toString();
	}	

	@RequestMapping("/article/write")
	public String showWrite() {
		return "article/write";
	}

	@RequestMapping("/article/doWrite")
	@ResponseBody
	public String doWrite(@RequestParam Map<String, Object> param) {
		long newId = articleService.doWrite(param);

		String msg = newId + "번 게시물이 추가되었습니다.";

		StringBuilder sb = new StringBuilder();

		sb.append("alert('" + msg + "');");
		sb.append("location.replace('./detail?id=" + newId + "');");

		sb.insert(0, "<script>");
		sb.append("</script>");

		return sb.toString();
	}
	

	@RequestMapping("/article/modify")
	public String showModify(int id, Model model) {
		Article article = articleService.getArticleById(id);

		model.addAttribute("article", article);

		return "article/modify";
	}

	@RequestMapping("/article/doModify")
	@ResponseBody
	public String doModify(@RequestParam Map<String, Object> param, long id) {
		articleService.modify(param);

		String msg = id + "번 게시물이 수정되었습니다.";

		StringBuilder sb = new StringBuilder();

		sb.append("alert('" + msg + "');");
		sb.append("location.replace('./detail?id=" + id + "');");

		sb.insert(0, "<script>");
		sb.append("</script>");

		return sb.toString();
	}

	@RequestMapping("/article/doDelete")
	@ResponseBody
	public String doDelete(long id) {
		articleService.delete(id);

		String msg = id + "번 게시물이 삭제되었습니다.";

		StringBuilder sb = new StringBuilder();

		sb.append("alert('" + msg + "');");
		sb.append("location.replace('./list');");

		sb.insert(0, "<script>");
		sb.append("</script>");

		return sb.toString();
	}

}
