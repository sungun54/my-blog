package com.sbs.java.blog.controller;

import java.sql.Connection;
import java.util.Map;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.dto.Member;
import com.sbs.java.blog.service.ArticleService;
import com.sbs.java.blog.service.MemberService;
import com.sbs.java.blog.util.Util;

public class MemberController extends Controller {
	
	public MemberController(Connection dbConn,	String actionMethodName, HttpServletRequest req, HttpServletResponse resp) {
		super(dbConn, actionMethodName, req, resp);
	}

	public void beforeAction() {
		super.beforeAction();
	}
	
	@Override
	public String doAction() {
		switch (actionMethodName) {
		case "login":
			return doActionLogin(req, resp);
		case "doLogin":
			return doActionDoLogin(req, resp);
		case "join":
			return doActionJoin(req, resp);
		case "doJoin":
			return doActionDoJoin(req, resp);
		}

		return "";
	}

	private String doActionDoJoin(HttpServletRequest req, HttpServletResponse resp) {
		String loginId = req.getParameter("loginId");
		String name = req.getParameter("name");
		String nickname = req.getParameter("nickname");
		String loginPw = req.getParameter("loginPwReal");
		String email= req.getParameter("email");
		
		Map<String, Object> Overlap = memberService.loginIdOverlap(loginId);
		
		if(Overlap.size() > 0 ) {
			return "html:<script> alert('이미 있는 아이디입니다.'); location.replace('join'); </script>";
		}
		
		int id = memberService.join(loginId, name, nickname, loginPw, email);
		
		return "html:<script> alert('" + id + "번 회원이 생성되었습니다.'); location.replace('../home/main'); </script>";
	}

	private String doActionJoin(HttpServletRequest req, HttpServletResponse resp) {
		return "member/join.jsp";
	}

	private String doActionDoLogin(HttpServletRequest req, HttpServletResponse resp) {
		String loginId = req.getParameter("loginId");
		String loginPw = req.getParameter("loginPw");		
		
		Map<String, Object> member = memberService.login(loginId, loginPw);
		
		if(member.size() == 0) {
			return "html:<script> alert('아이디 혹은 비밀번호가 일치하지않습니다.'); location.replace('login'); </script>";
		}
		
		req.setAttribute("member", member);
		
		return "html:<script> alert('" + member.get("id") + "번 회원이 로그인되었습니다.'); location.replace('../home/main'); </script>";
	}

	private String doActionLogin(HttpServletRequest req, HttpServletResponse resp) {
		return "member/login.jsp";
	}

}
